import React, { useState } from "react";
import Main from "../components/home/main/Main";
import { BrowserRouter, Route, Switch, Redirect, useHistory } from 'react-router-dom';
import FormCreateAccount from '../components/home/main/FormCreateAccount'
import Login from '../components/home/main/login'
import Header from "../components/home/header/Header";
import Footer from "../components/home/footer/Footer";
import Home from "../components/home/main/home";
import Product from "../components/product_detail/product_detail";
import history from './history'

const IdProductSelected = React.createContext(0);

/* let aux = 0; */

function App (props) {

  /* constructor (props) {
    super(props);
    this.state = {
      idProduct: 0
    };
  } */
  
  const [id, setId] = useState({idProduct: 0})
  

  const handleClick = (event) => {
    event.preventDefault()
    event.stopPropagation();
    console.log("evento_App");
    console.log(event.target.id);
    
    if (event.target.id !== 0) {
      let aux = event.target.id; // Hasta acá anda.
      this.setState({idProduct: aux})
      /* this.redirect(); */
      /* this.props.history.push("http://localhost:3000/product_detail/" + this.state.idProduct) */
    }
  }

  const redirect = () => {
    window.location.assign("http://localhost:3000/product_detail/" + id.idProduct);
  }

  /* componentDidUpdate (prevProps) {
    window.location.assign("http://localhost:3000/product_detail/" + prevProps.idProduct);
  } */

  /* componentWillUnmount () {
    this.setState({idProduct: aux})
  } */

  
    console.log(history)
    console.log("HANLDE_APP")
    console.log(id.idProduct)
    return (
      // <div className="App">
      <BrowserRouter>
        <Switch>
          <Route exact path={"/" || "/home"} /* component={Home} */>
            <Home handleClick={handleClick}/>
          </Route>
          <Route path='/product_detail' /* component={Product} */>
            {/* <IdProductSelected.Provider value={aux}> */}
              <Product idProduct={id.idProduct}/>
            {/* </IdProductSelected.Provider> */}
          </Route>
        </Switch>
  
  
      </BrowserRouter>
      //{/* </div> */}
    );
  
};

export default App;
