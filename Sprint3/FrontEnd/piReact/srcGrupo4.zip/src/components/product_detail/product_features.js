import React from 'react';
import styles from '../../styles/product_detail/productFeaturesStyle.module.css';
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import { FaSink, FaSnowflake, FaCar, FaParking, FaWifi, FaTv, FaDog, FaSwimmer, FaSwimmingPool } from 'react-icons/fa'; // Importo íconos de lavamanos, copo de nieve 1, auto, wifi, tv, perro, nadador y pileta.
import { MdOutlineKitchen, MdOutlinePets } from 'react-icons/md'; // Importo íconos de heladera, mascota.
import { BsSnow2 } from 'react-icons/bs'; // Importo íconos de copo de nieve 2.
import { IoCarSport, IoTv } from 'react-icons/io5'; // Importo íconos de auto 2, tv 4.
import { IoIosTv } from 'react-icons/io'; // Importo íconos de  tv 5.
import { RiHomeWifiFill } from 'react-icons/ri'; // Importo íconos de wifi 2.
import { GiTv, GiTvRemote } from 'react-icons/gi'; // Importo íconos de tv 2, tv 3.
import {faEyeSlash, faSnowflake, faSink, faCar, faWifi, faTv, faPaw, faSwimmer} from '@fortawesome/free-solid-svg-icons'; //Importo ícono de FontAwesome.

export default function Features () {

    return (
        <div id={styles.container_features}>
            <h2 id={styles.title_h2}>¿Qué ofrece este lugar?</h2>
            <hr className={styles.hr_detail}/>
            <div id={styles.container_items}>
                <div>
                    {/* <FontAwesomeIcon className={styles.icon} icon={faSink}/> */}
                    <FaSink className={styles.icon}/>                    
                    {/* <MdOutlineKitchen className={styles.icon}/> // Otra opción para la cocina.*/}                    
                    <p className={styles.paragraph}>Cocina</p>
                </div>
                <div>
                    {/* <FontAwesomeIcon className={styles.icon} icon={faSnowflake}/> */}
                    <FaSnowflake className={styles.icon}/>
                    {/* <BsSnow2 className={styles.icon}/> //Otra opción para el copo de nieve.*/}
                    <p className={styles.paragraph}>Aire acondicionado</p>
                </div>
                <div>
                    {/* <FontAwesomeIcon className={styles.icon} icon={faCar} /> */}
                    <FaCar className={styles.icon}/>
                    {/* <IoCarSport className={styles.icon}/> //Otra opción para el auto */}
                    <p className={styles.paragraph}>Estacionamiento gratuito</p>
                </div>
                <div>
                    {/* <FontAwesomeIcon className={styles.icon} icon={faWifi} /> */}
                    <FaWifi className={styles.icon}/>
                    {/* <RiHomeWifiFill className={styles.icon}/> //Otra opción de Wifi */}
                    <p className={styles.paragraph}>Wifi</p>
                </div>
                <div>
                    {/* <FontAwesomeIcon className={styles.icon} icon={faTv} /> */}
                    <FaTv className={styles.icon}/>
                    {/* <GiTv className={styles.icon}/>
                    <GiTvRemote className={styles.icon}/>
                    <IoTv className={styles.icon}/>
                    <IoIosTv className={styles.icon}/> //Otras opciones para TVs*/}
                    <p className={styles.paragraph}>Televisor</p>
                </div>
                <div>
                    {/* <FontAwesomeIcon className={styles.icon} icon={faPaw} /> */}
                    <MdOutlinePets className={styles.icon}/>
                    {/* <FaDog className={styles.icon}/> //Otra opción para mascotas */}
                    <p className={styles.paragraph}>Apto mascotas</p>
                </div>
                <div>
                   {/* <FontAwesomeIcon className={styles.icon} icon={faSwimmer} /> */}
                   <FaSwimmer className={styles.icon}/>
                   {/* <FaSwimmingPool className={styles.icon}/> //Otra opción para pileta */}
                    <p className={styles.paragraph}>Pileta</p>
                </div>
            </div>
        </div>
    )

}