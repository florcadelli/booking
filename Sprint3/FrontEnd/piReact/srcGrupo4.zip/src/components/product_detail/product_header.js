import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { MdArrowBackIos } from 'react-icons/md'; // Importo ícono de flecha.
import {faSolidFaChevronLeft} from '@fortawesome/free-solid-svg-icons'; //Importo ícono de FontAwesome.
import styles from '../../styles/product_detail/productHeader.module.css';
import IdProductSelected from '../../container/App'
/* const location = useLocation(); */

class ProductHeader extends React.Component {

    constructor (props) {
        super(props);
        this.state = {
          products: []
          /* id: location.pathname.substring(location.pathname.length()-1, location.pathname.length()) */
        }
    }

    static contextType = IdProductSelected;

    componentDidMount() { // Obtengo todos los productos.
        fetch('http://localhost:8080/products/list', { method: 'GET' })
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Something went wrong ...');
                }
            })
            .then(data => {
                console.log(data)
                this.setState({ products: data })
            })
    }

    render() {
        const aux = this.props.idProduct
        console.log("Id obtenida: " + aux); //undefined
        return (
            <div id={styles.container_header}>
                {/* {console.log(this.state.id)} */}
                <div>
                    <h3 id={styles.h3_header}>{ this.state.products.map(function (product) {
                        if (product.id === aux) {
                            return product.category
                        } else {
                            return ""
                        }
                    })}</h3> {/* <!--InyectarcategoríadesdelaAPI--> */}
                    <h2 id={styles.h2_header}>Cabaña en Bariloche</h2> {/* <!--Inyectar nombre del producto desde la API--> */}
                </div>
                <a href="/"><MdArrowBackIos id={styles.arrow}/></a>
                {/* <a href="#"><i class="fa-solid fa-chevron-left"></i></a> */}
            </div>
        )
    }

}

export default ProductHeader;