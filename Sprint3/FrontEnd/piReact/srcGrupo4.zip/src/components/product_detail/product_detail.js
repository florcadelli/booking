import React from "react";
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom'; // Importo componente para utilizar Router.
import Header from "../home/header/Header"; // Importo componente del Header.
import Footer from "../home/footer/Footer"; // Importo componente del Footer.
import Policies from "./product_policies"; // Importo componente de las políticas del producto.
import ProductHeader from "./product_header"; // Importo componente del nuevo header.
import Features from './product_features'; // Importo componente de características.
import Dates from './product_dates'; //Importo componente de fechas.


export default function Product (props) {
    console.log("id_product_DETAIL")
    /* console.log(props.id_product) // Vale 0. */
    const aux = props.idProduct
    console.log(aux) // Vale 0.

    return (<>
        <Header idProduct={aux}/>
        <ProductHeader/>
        {/* Falta cuerpo del detalle del producto */}
        
        <main>
            <Features/>
            <Dates/>
            <Policies/>
        </main>
        
        <Footer/>
    </>)

}