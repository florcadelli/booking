import React from 'react'

const FunctionComponent = ({props}) => {
return (
<li></li>
)
}

export default FunctionComponent
