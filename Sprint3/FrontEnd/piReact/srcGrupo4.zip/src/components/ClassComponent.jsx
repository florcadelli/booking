import React, { Component } from 'react'

 class ClassComponent extends Component {

    
render() {
return (
<li></li>
)
}
}

export default ClassComponent