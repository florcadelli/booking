import React from "react"; // Importo componente de React
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom'; // Importo componente para utilizar Router.
import Header from "../header/Header"; // Importo componente de Header.
import Footer from "../footer/Footer"; // Importo componente de Footer.
import Main from "./Main"; // Importo componente de Main.
import FormCreateAccount from './FormCreateAccount' // Importo componente de registro.
import Login from './login' // Importo componente de login.

export default function Home (props) {

    console.log("HANDLE_HOME")
    console.log(props.handleClick)

    return (
        <BrowserRouter>
        <Redirect to='/home' />
                <Header/>
                <Switch>
                    <Route exact path="/"></Route>
                    <Route exact path='/logedin'></Route>
                    <Route path="/createAccount" component={FormCreateAccount}></Route>
                    <Route path="/login" component={Login}><Login/></Route>
                </Switch>
                <Main handleClick={props.handleClick}/>
                <Footer/>
        </BrowserRouter>
    )

}