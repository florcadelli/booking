import React from 'react'
import Searcher from "./Searcher";
import Recom from "./Recom";
import Categories from './Categories';


class Main extends React.Component {

  constructor (props) {
    super(props);
    this.state = {
      cities: [],
      categories: []
    }
  }
  
  componentDidMount () { // Obtengo las ciudades y países.
    fetch('http://localhost:8080/cities/list',{method: 'GET'})
    .then(response => {
      if (response.ok) {
        return response.json();
      } /* else {
        throw new Error('Something went wrong ...');
      } */
    })
    .then(data => {
      console.log("anda el fetch de ciudades y países")
      console.log(data)
      this.setState({cities: data})
    })
    fetch('http://localhost:8080/categories/list',{method: 'GET'}) // Obtengo las categorías.
    .then(response => {
      if (response.ok) {
        return response.json();
      } /* else {
        throw new Error('Something went wrong ...');
      } */
    })
    .then(data => {
      console.log("anda el fetch de categorías")
      console.log(data)
      this.setState({categories: data})
    })
  }

  render () {

    return (
      <main>
        <Searcher cities={this.state.cities}/>
        <Categories categories={this.state.categories}/>
        <Recom handleClick={this.props.handleClick}/>
      </main>
    )
  }
}

export default Main
