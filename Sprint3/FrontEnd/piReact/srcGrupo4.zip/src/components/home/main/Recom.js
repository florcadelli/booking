import React from 'react';
import CardRecom from './CardRecom';
import data from "../../../json/bloqueListado.json";

class Recom extends React.Component {

    constructor(props) {
        super(props);
        /* this.handleClick = this.handleClick.bind(this); */
        this.state = {
            products: []
        }
    }

    componentDidMount() { // Obtengo todos los productos.
        fetch('http://localhost:8080/products/list', { method: 'GET' })
            .then(response => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Something went wrong ...');
                }
            })
            .then(data => {
                console.log(data)
                this.setState({ products: data })
            })
    }

    render() {
        console.log("HANDLE_recom")
        console.log(this.props.handleClick)
        const aux = this.props.handleClick;
        return (
            <>
                <section className="recom">
                    <h2 class="titleRecom">Recomendaciones</h2>
                    <div className="cardContainerRecom">
                        {/* {data.map((card, index)=>{ 
                        console.log(card.title)
                        return <CardRecom key={index} id={card.id} img={card.img} category={card.category} title={card.title} location={card.location} description={card.description } />
                        })} */}
                        {this.state.products.map(function (product, index) {
                            return (
                                <CardRecom handleClick={aux} key={index} id={product.id} img={product.images[0].url} category={product.category.title} title={product.name} location={product.city.name} description={product.description}/>
                            )
                        })}
                        {/* Genero las cards con los productos obetnidos de la API. */}
                        {/* {this.state.products.map((product)=>{ 
                        console.log(product.name)
                        return <CardRecom key={product.id} id={product.id} img={product.images[0]} category={product.category} title={product.name} location={product.city} description={product.description } />
                        })} */}
                    </div>
                </section>
            </>
        );
    }
}

export default Recom;