import React from 'react'; // Importo React.
import '../../../styles/__forms.css'; // Importo los estilos CSS.

export default function Login_button() {
    
    return (<>
        <button className="form-button">Ingresar</button>
    </>)

        //Nota: No tiene mucho sentido este componente. Podríamos quitarlo.

}