import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faHeart, faSwimmer, faWifi} from '@fortawesome/free-solid-svg-icons';
import iconStar from '../../../assets/img/iconStar.svg';
import iconSwimming from '../../../assets/img/iconSwimming.svg';
import data from "../../../json/bloqueListado.json";
import {Link, Redirect, withRouter} from "react-router-dom"; // Importo los componentes de React Router.
import { checkPropTypes } from 'prop-types';

/* class CardRecom extends React.Component{
    constructor(props){
        super();
        this.state = {
            redirect: false,
            redirect_path: ""
        }
        
    }
    
    handleClick = () => {
        this.setState({redirect: true, redirect_path: "/product_detail"})
    }

    render(){

        const { history } = this.props
        {if (this.state.submit) {
            history.push("/product_detail")
        }}
        
        return(
            <div className="cardContainerRecom">
                    <div className="cardRecom">
                        <div className="card-bg">
                        <FontAwesomeIcon icon={faHeart} />   
                        <img src=""></img>
                        </div>
                        <div className="card-texto">
                            <div className="ranking"> 
                                <div>
                                    <h4>CASAS <img src={iconStar} alt=""/><img src={iconStar} alt=""/><img src={iconStar} alt=""/><img src={iconStar} alt=""/><img src={iconStar} alt=""/> </h4>
                                    <h3>{this.props.title}</h3>
                                </div>
                                <div className="rankingContainer">
                                    <a className="btnRanking" href="">8</a>
                                    <h4>Muy bueno</h4>
                                </div>
                            </div>
                            <h4><i className="fas fa-map-marker-alt"></i> A 920 km del centro <span>MOSTRAR EN EL MAPA</span></h4>
                            <div className="icons"> 
                            <FontAwesomeIcon icon={faWifi}/>
                            <FontAwesomeIcon icon={faSwimmer}/>
                            </div>
                            <p>{} <span>más...</span> </p>
                            <Link className="btnVerMas" onClick={this.handleClick} to={{pathname: "/product_detail", search: "?sort=id"}}>ver más</Link>
                        </div>
                    </div>
                </div>
        )
    }
}  */

function CardRecom ({id, img, category, title, location, description, handleClick} ) {
    return (

    <>      

                    <div className="cardRecom">
                        <div className="card-bg">
                            <FontAwesomeIcon icon={faHeart} />   
                            <img src={img}></img>
                        </div>
                        <div className="card-texto">
                            <div className="ranking"> 
                                <div className="tituloCardRecom">
                                    <h5>{category/* DEBE ESTAR EN MAYÚSCULAS PERO TIRA ERROR .toUpperCase() */} <img src={iconStar} alt=""/><img src={iconStar} alt=""/><img src={iconStar} alt=""/><img src={iconStar} alt=""/><img src={iconStar} alt=""/> </h5>
                                    <h3>{title}</h3>
                                </div>
                                <div className="rankingContainer">
                                    <a className="btnRanking" href="">8</a>
                                    <h4>Muy bueno</h4>
                                </div>
                            </div>
                            <h4><i className="fas fa-map-marker-alt"></i> {location} <span className="spanMain">MOSTRAR EN EL MAPA</span></h4>
                            <div className="icons"> 
                            <FontAwesomeIcon icon={faWifi}/>
                            <img src={iconSwimming} alt=""/>
                            </div>
                            <p class="descripText">{description} </p> <span className="spanMain">más...</span> 
                            <Link onClick={handleClick} id={id} className="btnVerMas" to={"/product_detail/" + id}></Link>
                            {/* <a onClick={handleClick} id={id} className="btnVerMas" href={"/product_detail/" + id}>ver más</a> */}
                            {/* Después hay que colocarle el id del producto */}
                        </div>
                    </div>  
    </>
    );
} 

export default CardRecom;