package com.dh.Grupo4.trabajoIntegrador.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "products")
@Getter @Setter
public class Product {

    @Id
    @GeneratedValue
    private Long id;

    private String name;
    private String description;
    private String title_description;

    @OneToMany
    @JoinColumn(name = "product_id")
    private List<Image> images;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @ManyToOne
    @JoinColumn(name = "city_id", nullable = false)
    private City city;

    @ManyToMany
    @JoinTable(name = "product_feature",
            joinColumns =  @JoinColumn(name = "id_product") ,
            inverseJoinColumns = @JoinColumn(name = "id_feature")
    )
    private Set<Feature> features;

    public Product() {
    }


    public Product(String name, String description,String title_description, List<Image> images, Category category, City city, Set<Feature> features) {
        this.name = name;
        this.description = description;
        this.title_description = title_description;
        this.images = images;
        this.category = category;
        this.city = city;
        this.features = features;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
