package com.dh.Grupo4.trabajoIntegrador.controller;

import com.dh.Grupo4.trabajoIntegrador.model.DTO.ReservationDTO;
import com.dh.Grupo4.trabajoIntegrador.service.IReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;
import java.util.Set;

@RestController
@CrossOrigin(origins = "*", methods= {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
@RequestMapping("/reservations")
public class ReservationController {

    @Autowired
    IReservationService iReservationService;

    // Métodos pedidos en la Issue #47 - Sprint 3

    @PostMapping // Permite crear una nueva reserva.
    public ResponseEntity<?> addReservation(@RequestBody ReservationDTO reservationDTO) {

        iReservationService.createReservation(reservationDTO);
        return ResponseEntity.ok(HttpStatus.CREATED);

    }

    @GetMapping("/list/product/{id}") // Permite encontrar las reservas asociadas a un producto por su Id.
    public Collection<ReservationDTO> findReservationByProductId (@PathVariable Long id) {

        return iReservationService.readReservationByProductId(id);

    }

    // Métodos extra que pueden servir para realizar pruebas.

    @DeleteMapping("/delete/{id}") // Permite borrar una reserva por su id.
    public ResponseEntity<?> deleteReservationById (@PathVariable Long id) {

        iReservationService.deleteReservationById(id);
        return ResponseEntity.ok(HttpStatus.OK);

    }

    @GetMapping("/{id}")
    public ReservationDTO findReservationById (Long id) { // Permite encontrar una reserva por su id.

        return iReservationService.readReservationById(id);

    }

    @GetMapping("/list")
    public Set<ReservationDTO> findAllReservations () { // Permite traer todas las reservas de la BDD.

        return iReservationService.readReservations();

    }

}
