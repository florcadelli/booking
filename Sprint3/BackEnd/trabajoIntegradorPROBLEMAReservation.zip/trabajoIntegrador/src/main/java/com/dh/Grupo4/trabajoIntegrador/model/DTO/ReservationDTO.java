package com.dh.Grupo4.trabajoIntegrador.model.DTO;

import com.dh.Grupo4.trabajoIntegrador.model.Product;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter @Setter
public class ReservationDTO {

    private Long id;
    private Integer startTime;
    private Date startDate;
    private Date finalDate;
    private Product product;

    public ReservationDTO() {
    }

    public ReservationDTO(Integer startTime, Date startDate, Date finalDate, Product product) {
        this.startTime = startTime;
        this.startDate = startDate;
        this.finalDate = finalDate;
        this.product = product;
    }
}
