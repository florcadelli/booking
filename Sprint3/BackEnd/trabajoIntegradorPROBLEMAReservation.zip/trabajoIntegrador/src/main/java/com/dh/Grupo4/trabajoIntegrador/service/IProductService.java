package com.dh.Grupo4.trabajoIntegrador.service;

import com.dh.Grupo4.trabajoIntegrador.model.DTO.ProductDTO;

import java.util.Collection;

public interface IProductService {

    void createProduct(ProductDTO productDTO);
    void updateProduct(ProductDTO productDTO);
    void deleteProduct(Long id);
    Collection<ProductDTO> readProducts();
    Collection<ProductDTO> findProductByCity(String name);
    Collection<ProductDTO> findProductByCategory(String title);
    ProductDTO readProduct(Long id);
}
