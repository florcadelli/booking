package com.dh.Grupo4.trabajoIntegrador.repository;

import com.dh.Grupo4.trabajoIntegrador.model.City;
import com.dh.Grupo4.trabajoIntegrador.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public interface IProductRepository extends JpaRepository<Product, Long> {

    @Query("select p from Product p where p.city.name like ?1")
    Collection<Product> findProductByCity(String name);

    @Query("select p from Product p where p.category.title like ?1")
    Collection<Product> findProductByCategory(String title);
}
