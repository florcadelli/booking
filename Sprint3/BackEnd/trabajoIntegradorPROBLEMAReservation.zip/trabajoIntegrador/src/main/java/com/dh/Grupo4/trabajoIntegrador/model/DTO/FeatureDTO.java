package com.dh.Grupo4.trabajoIntegrador.model.DTO;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FeatureDTO {

    private Long id;
    private String name;
    private String icon;
}
