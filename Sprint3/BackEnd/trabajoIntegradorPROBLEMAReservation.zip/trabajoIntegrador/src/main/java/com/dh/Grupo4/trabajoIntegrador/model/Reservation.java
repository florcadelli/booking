package com.dh.Grupo4.trabajoIntegrador.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.sql.Time;
import java.util.Date;

@Entity
@Table(name = "reservations")
@Getter @Setter
public class Reservation {

    @Id
    @GeneratedValue
    private Long id;

    private Integer startTime;
    private Date startDate;
    private Date finalDate;

    @ManyToOne//(cascade = CascadeType.ALL)
    @JoinColumn(name = "product_id")
    private Product product;

    public Reservation() {
    }

    public Reservation(Integer startTime, Date startDate, Date finalDate, Product product) {
        this.startTime = startTime;
        this.startDate = startDate;
        this.finalDate = finalDate;
        this.product = product;
    }
}
