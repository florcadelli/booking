package com.dh.Grupo4.trabajoIntegrador.model.DTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleDTO {

    private Long id;
    private String name;


    public RoleDTO() {
    }
}
