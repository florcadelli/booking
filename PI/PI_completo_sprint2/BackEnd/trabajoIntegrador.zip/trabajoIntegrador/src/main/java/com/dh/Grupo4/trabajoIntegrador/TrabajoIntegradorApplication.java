package com.dh.Grupo4.trabajoIntegrador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajoIntegradorApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajoIntegradorApplication.class, args);
	}

}
